<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Berat extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->model('BeratModel');
	}

	public function index()
	{
		$this->catatBerat();
	}

	public function catatBerat(){
		$data = [];
		$sql = 'select * from berat order by tanggal desc';
		$data['berat'] = $this->BeratModel->runSqlCommand($sql)->result_array();
		$sql = 'select avg(max) as max, avg(min) as min, avg(max-min) as perbedaan from berat';
		$data['rataRata'] = $this->BeratModel->runSqlCommand($sql)->row_array();
		$this->load->view('catatBerat', $data);
	}

	public function actionDelete(){
		if(isset($_POST['inputTanggal'])){
			$tanggal = $_POST['inputTanggal'];
			$this->BeratModel->runSqlCommand('delete from berat where tanggal = "'.date('Y-m-d', strtotime($tanggal)).'"');
			redirect(base_url().'index.php/Berat/catatBerat');
		} else {
			redirect(base_url().'index.php/Berat/catatBerat');
		}
	}

	public function actionEdit(){
		if(isset($_POST['inputTanggal']) && isset($_POST['inputMin']) && isset($_POST['inputMax'])){
			$tanggal = $_POST['inputTanggal'];
			$max = $_POST['inputMax'];
			$min = $_POST['inputMin'];
			$this->BeratModel->runSqlCommand('update berat set max = '.$max.', min = '.$min.' where tanggal = "'.date('Y-m-d', strtotime($tanggal)).'"');
			redirect(base_url().'index.php/Berat/catatBerat');
		} else {
			redirect(base_url().'index.php/Berat/catatBerat');
		}
	}

	public function actionAdd(){
		if(isset($_POST['inputTanggal']) && isset($_POST['inputMin']) && isset($_POST['inputMax'])){
			$max = $_POST['inputMax'];
			$min = $_POST['inputMin'];
			$tanggal = date('Y-m-d', strtotime($_POST['inputTanggal']));
			$this->BeratModel->runSqlCommand('INSERT INTO `berat`(`tanggal`, `max`, `min`) values ("'.$tanggal.'", '.$max.', '.$min.')');
			redirect(base_url().'index.php/Berat/catatBerat');
		} else {
			redirect(base_url().'index.php/Berat/catatBerat');
		}
	}
}
