<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class BeratModel extends CI_Model {
	public function __construct(){
		parent::__construct();

	}

	public function runSqlCommand($sql){
		return $this->db->query($sql);
	}
}
