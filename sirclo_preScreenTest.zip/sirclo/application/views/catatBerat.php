<!DOCTYPE html>
<html>
<head>
	<title>Catat Berat</title>
	<?php
		include 'include/global_css.php';
		include 'include/global_js.php';
	?>
</head>
<style type="text/css">
	tr,td,th{
		text-align: center !important;
	}
</style>
<body>
	<div class="row">&nbsp;</div>
	<div class="row">
		<div class="col-md-1">&nbsp;</div>
		<div class="col-md-2">&nbsp;</div>
		<button type="button" id="btnAdd" class="button col-md-2" style="float: left;">Tambah Data</button>
	</div>
	<div class="row">&nbsp;</div>
	<div class="row">
		<div class="col-md-1">&nbsp;</div>
		<div class="col-md-4">
			<table id="tbDataBerat" class="table table-striped table-bordered">
				<thead>
					<tr>
						<th>Tanggal</th>
						<th>Max</th>
						<th>Min</th>
						<th>Perbedaan</th>
					</tr>
				</thead>
				<tbody id="bodyTbDataBerat">
					<?php
						foreach ($berat as $key => $value) {
							echo "<tr>";
							echo '<td class="tgl">'.$value['tanggal'].'</td>';
							echo '<td class="mx">'.$value['max'].'</td>';
							echo '<td class="mn">'.$value['min'].'</td>';
							echo '<td class="bd">'.($value['max']-$value['min']).'</td>';
							echo "</tr>";
						}
					?>
				</tbody>
				<tfoot>
					<tr>
						<?php
							echo '<th>Rata-Rata</th>';
							echo '<th>'.$rataRata['max'].'</th>';
							echo '<th>'.$rataRata['min'].'</th>';
							echo '<th>'.$rataRata['perbedaan'].'</th>';					
						?>
					</tr>
				</tfoot>
			</table>
		</div>
	</div>
	<div id="mdlDt" class="modal fade" role="dialog">
		<div class="modal-dialog">
			<!-- Modal content-->
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title">Data Berat</h4>
				</div>
				<div class="modal-body">
					<form id="frmAction" method="POST" action="">
						<table class="table table-striped table-bordered">
							<tr>
								<th>
									Tanggal
								</th>
								<td id="mdlDtTanggal">
									<input type="date" name="inputTanggal">
								</td>
							</tr>
							<tr>
								<th>
									Max
								</th>
								<td id="mdlDtMax">
									<input type="number" name="inputMax">
								</td>
							</tr>
							<tr>
								<th>
									Min
								</th>
								<td id="mdlDtMin">
									<input type="number" name="inputMin">
								</td>
							</tr>
							<tr>
								<th>
									Perbedaan
								</th>
								<td id="mdlDtPerbedaan">
									<input type="number" name="inputPerbedaan" readonly>
								</td>
							</tr>
							<tr>
								<td colspan="2">
									<button type="button" id="btnDelete">Delete</button>
									<button type="button" id="btnEdit">Edit</button>
									<button type="button" id="btnCancel">Cancel</button>
									<button type="button" id="btnActionEdit">Edit</button>
									<button type="button" id="btnCreate">Create</button>
								</td>
							</tr>
						</table>
					</form>
					
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				</div>
			</div>
		</div>
	</div>
</body>
</html>
<script type="text/javascript">
	$('#tbDataBerat').DataTable();
	$('#btnAdd').unbind().on('click', function(){
		$('#btnDelete').hide();
		$('#btnActionEdit').hide();
		$('#btnEdit').hide();
		$('#btnCreate').show();
		$('#btnCancel').hide();
		$('[name="inputTanggal"]').attr('readonly', false);
		$('[name="inputMax"]').attr('readonly', false);
		$('[name="inputMin"]').attr('readonly', false);
		$('[name="inputPerbedaan"]').attr('readonly', true);
		$('[name="inputTanggal"]').val('');
		$('[name="inputMax"]').val('');
		$('[name="inputMin"]').val('');
		$('[name="inputPerbedaan"]').val('');
		$('[name="inputMax"],[name="inputMin"]').unbind().on('change', function(){
			$('[name="inputPerbedaan"]').val($('[name="inputMax"]').val() - $('[name="inputMin"]').val());
		});
		$('#mdlDt').modal({
			show: true
		});
		$('#frmAction').attr('action', "<?php echo base_url();?>index.php/Berat/actionAdd");
		$('#btnCreate').unbind().on('click', function(){
			$('#frmAction').submit();
		});
	});

	function modalDataShow(param){
		$('#btnDelete').show();
		$('#btnActionEdit').hide();
		$('#btnEdit').show();
		$('#btnCreate').hide();
		$('#btnCancel').hide();

		$('[name="inputTanggal"]').attr('readonly', true);
		$('[name="inputMax"]').attr('readonly', true);
		$('[name="inputMin"]').attr('readonly', true);
		$('[name="inputPerbedaan"]').attr('readonly', true);
		$('[name="inputTanggal"]').val(param.children('.tgl').html());
		$('[name="inputMax"]').val(param.children('.mx').html());
		$('[name="inputMin"]').val(param.children('.mn').html());
		$('[name="inputPerbedaan"]').val($('[name="inputMax"]').val() - $('[name="inputMin"]').val());
		$('#frmAction').attr('action', "");
	}
	$('#tbDataBerat tbody tr').unbind().on('click', function(){
		var context = $(this);
		$('#mdlDt').modal({
			show: true
		});
		modalDataShow(context);
		$('#btnDelete').unbind().on('click', function(){
			$('#frmAction').attr('action', "<?php echo base_url();?>index.php/Berat/actionDelete");
			if(confirm('Apus ni data?')){
				$('#frmAction').submit();
			} else {
				$('#frmAction').attr('action', "");
			}
		});

		$('#btnEdit').unbind().on('click', function(){
			$('#frmAction').attr('action', "<?php echo base_url();?>index.php/Berat/actionEdit");
			$('#btnDelete').hide();
			$('#btnActionEdit').show();
			$('#btnEdit').hide();
			$('#btnCreate').hide();
			$('#btnCancel').show();
			$('[name="inputMax"]').attr('readonly', false);
			$('[name="inputMin"]').attr('readonly', false);
			$('[name="inputMax"],[name="inputMin"]').unbind().on('change', function(){
				$('[name="inputPerbedaan"]').val($('[name="inputMax"]').val() - $('[name="inputMin"]').val());
			});
			$('#btnActionEdit').unbind().on('click', function(){
				$('#frmAction').submit();
			});

			$('#btnCancel').unbind().on('click', function(){
				modalDataShow(context);
			});
		});
	});


</script>