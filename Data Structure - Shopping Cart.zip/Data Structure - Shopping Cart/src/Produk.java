public class Produk {
    private String kodeProduk;
    private int kuantitas;

    public String getKodeProduk() {
        return kodeProduk;
    }

    public void setKodeProduk(String kodeProduk) {
        this.kodeProduk = kodeProduk;
    }

    public int getKuantitas() {
        return kuantitas;
    }

    public void setKuantitas(int kuantitas) {
        this.kuantitas = kuantitas;
    }

    public Produk(String kodeProduk, int kuantitas) {
        this.kodeProduk = kodeProduk;
        this.kuantitas = kuantitas;
    }
}
