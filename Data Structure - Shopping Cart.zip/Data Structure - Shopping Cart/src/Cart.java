import java.util.ArrayList;

public class Cart {
    private ArrayList<Produk> listCart = new ArrayList<Produk>();

    public Cart(ArrayList<Produk> listCart) {
        this.listCart = listCart;
    }

    public Cart(){}

    public ArrayList<Produk> getListCart() {
        return listCart;
    }

    public void setListCart(ArrayList<Produk> listCart) {
        this.listCart = listCart;
    }

    public void tambahProduk(String kodeProduk, int kuantitas){
        int flag = 1;
        for (int i=0; i<listCart.size(); i++){
            if(listCart.get(i).getKodeProduk().toLowerCase().equals(kodeProduk.toLowerCase())){
                flag = 0;
                listCart.get(i).setKuantitas(listCart.get(i).getKuantitas() + kuantitas);
                break;
            }
        }
        if(flag == 1){
            listCart.add(new Produk(kodeProduk, kuantitas));
        }
    }

    public void hapusProduk(String kodeProduk){
        ArrayList<Produk> temp = listCart;
        for (int i=0; i<temp.size(); i++){
            if(temp.get(i).getKodeProduk().toLowerCase().equals(kodeProduk.toLowerCase())){
                temp.remove(i);
                break;
            }
        }
        this.listCart = temp;
    }

    public void tampilkanCart(){
        for(Produk produk: this.listCart){
            System.out.println(produk.getKodeProduk() + " (" + produk.getKuantitas() + ")");
        }
    }
}
